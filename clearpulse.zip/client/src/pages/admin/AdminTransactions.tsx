export default function AdminTransactions() {
  return <div className="p-8"><h1 className="text-3xl font-bold">Transaction Management</h1><p className="text-gray-600 mt-2">Admin feature under development</p></div>;
}