export default function AdminLoans() {
  return <div className="p-8"><h1 className="text-3xl font-bold">Loan Management</h1><p className="text-gray-600 mt-2">Admin feature under development</p></div>;
}